# THE LAST ALLIANCE
# Six chapters, persistent state, relationship logic, branching routes and endings.

label start:
    $ trust = 0
    $ suspicion = 0
    $ stress = 1
    $ credibility = 0
    $ influence = 0
    $ relationships = {"john": 0, "william": 0, "harry": 0, "yan": 0, "yuki": 0}
    $ flags = {k: False for k in flags}
    $ evidence = []
    $ messages = []
    $ chapter_seen = 0
    $ vote_record = "abstain"
    $ alliance_score = 0
    scene black
    centered "A PERSON CAN SURVIVE A LIE.\nA GROUP RARELY CAN."
    pause 1.2
    call screen chapter_card("PROLOGUE", "Six strangers. One sealed room. No neutral witnesses.")
    scene bg lounge with fade
    narrator "The first thing you notice is the clock."
    narrator "Not because it is broken. Because it is working."
    narrator "Its second hand moves. The minute hand does not."
    narrator "Six chairs surround a table. Five are occupied."
    narrator "The sixth chair has your name on it."
    p "Where are we?"
    show john portrait at right with dissolve
    john "A question with no useful answer."
    show william portrait at left with dissolve
    william "That's not true. The useful answer is: somewhere we cannot leave."
    show harry portrait:
        xalign 0.72 yalign 1.0 zoom 0.72
    harry "The door has no handle on this side."
    show yan portrait:
        xalign 0.28 yalign 1.0 zoom 0.72
    yan "And the cameras are real. I checked."
    show yuki portrait:
        xalign 0.5 yalign 1.0 zoom 0.72
    yuki "Please... can we not start by threatening each other?"
    hide john portrait
    hide william portrait
    hide harry portrait
    hide yan portrait
    hide yuki portrait
    system "WELCOME, PARTICIPANTS."
    system "THE LAST ALLIANCE IS A GAME OF SHARED INFORMATION."
    system "YOU MAY LIE. YOU MAY WITHHOLD. YOU MAY FORM ALLIANCES."
    system "YOU MAY NOT LEAVE BEFORE THE FINAL VOTE."
    p "Who is running this?"
    unknown "Someone who knows what each of you owes."
    narrator "A small envelope slides from a slot in the table."
    narrator "Inside are six identity cards and five voting cards."
    narrator "There should be six."
    $ add_evidence("Opening inventory: six identity cards, five voting cards.")
    $ stress += 1
    jump chapter_one

label chapter_one:
    $ chapter_seen = 1
    call screen chapter_card("CHAPTER 01", "The Silence Before the Vote")
    scene bg vote with fade
    narrator "Nobody reaches for the missing card."
    narrator "That is the first suspicious thing."
    show john portrait at right
    john "Before anyone accuses anyone, count the envelopes."
    show william portrait at left
    william "I already did. Five."
    show harry portrait:
        xalign 0.73 yalign 1.0 zoom 0.72
    harry "Maybe the sixth was never printed."
    show yan portrait:
        xalign 0.28 yalign 1.0 zoom 0.72
    yan "Then why does the inventory say six?"
    show yuki portrait:
        xalign 0.5 yalign 1.0 zoom 0.72
    yuki "There is something under the table."
    hide john portrait
    hide william portrait
    hide harry portrait
    hide yan portrait
    hide yuki portrait
    narrator "A strip of paper. Torn cleanly, not accidentally."
    narrator "The ink has bled through from the other side."
    menu:
        "Pick it up before anyone else can":
            $ flags["kept_card"] = True
            $ add_evidence("Torn voting-card strip: the reverse carries a debt reference.")
            $ influence += 2
            $ suspicion += 1
            narrator "You close your hand around it. Five pairs of eyes follow the movement."
            john "Interesting. You didn't ask what it was."
            $ relation("john", -1)
        "Show everyone the strip":
            $ flags["shared_clue"] = True
            $ add_evidence("Torn voting-card strip was shown to all five participants.")
            $ trust += 2
            $ credibility += 1
            narrator "You place it in the middle of the table."
            yuki "Thank you. At least someone is not hiding everything."
            $ relation("yuki", 2)
            $ relation("william", 1)
        "Leave it where it is and watch who reacts":
            $ suspicion += 2
            $ credibility += 1
            $ stress += 1
            narrator "You do not move. The silence stretches."
            narrator "William looks at the paper. John looks at you."
            $ relation("john", 1)
    $ clamp_stats()
    scene bg lounge with dissolve
    show william portrait at left
    william "The debt reference. I know that format."
    p "Whose debt?"
    william "Mine."
    narrator "He says it without looking at anyone."
    william "I borrowed money from a private lender. A lot of it. But the amount on that strip is wrong."
    show john portrait at right
    john "How wrong?"
    william "Wrong by exactly the amount someone would need to make me look desperate."
    p "You expect us to believe that?"
    william "No. I expect you to notice that I didn't deny the debt."
    narrator "His answer is too clean. It sounds rehearsed, but that does not make it false."
    menu:
        "Ask William for the lender's name":
            $ credibility += 1
            $ relation("william", 1)
            william "The name is a shell. Three companies, one address. I can show you later."
        "Accuse William of hiding the real amount":
            $ suspicion += 2
            $ relation("william", -2)
            william "Then don't ask me for help when the numbers stop making sense."
        "Ask John why he recognised the format":
            $ flags["confronted_john"] = True
            $ suspicion += 1
            $ relation("john", -1)
            john "Because I used to audit claims like this. That is all."
            p "You said the format before you saw the reverse."
            john "I saw your face when you read it."
    narrator "A speaker clicks."
    system "ROUND ONE: ONE PLAYER WILL BE SELECTED FOR PRIVATE REVIEW."
    system "THE GROUP MAY SUBMIT ONE NAME."
    menu:
        "Nominate William":
            $ vote_record = "william"
            $ flags["voted_william"] = True
            $ influence += 1
            $ relation("william", -2)
        "Nominate John":
            $ vote_record = "john"
            $ influence += 1
            $ relation("john", -2)
        "Nominate yourself":
            $ vote_record = "self"
            $ credibility += 2
            $ trust += 1
            $ stress += 2
        "Refuse to nominate anyone":
            $ vote_record = "abstain"
            $ suspicion += 1
            $ influence -= 1
    system "SUBMISSION RECORDED."
    narrator "No one is taken away."
    narrator "Instead, a red light appears above the empty chair."
    system "YOUR FIRST DECISION HAS BEEN RECORDED. NOT YOUR FIRST ANSWER."
    $ clamp_stats()
    jump chapter_two

label chapter_two:
    $ chapter_seen = 2
    call screen chapter_card("CHAPTER 02", "The Carbon Copy")
    scene bg archive with fade
    narrator "The archive is unlocked at 02:13."
    narrator "Inside are two copies of the same report."
    narrator "The first is dated yesterday. The second is dated tomorrow."
    show yan portrait at right
    yan "Don't touch the staples."
    p "Why?"
    yan "Because the second copy was assembled after the first one was sealed."
    show harry portrait at left
    harry "That is impossible."
    yan "Only if you believe the timestamp."
    narrator "The pages differ in three places: a comma, a name, and the time of a phone call."
    $ add_evidence("Carbon copy: two versions differ in punctuation, one name, and a call timestamp.")
    menu:
        "Compare the paper fibres and staple holes":
            $ credibility += 2
            $ stress += 1
            yan "Good. Physical evidence. The staple holes don't line up."
            $ add_evidence("Staple holes on the second copy were made after the page was printed.")
            $ relation("yan", 2)
        "Compare the timestamps first":
            $ suspicion += 1
            $ influence += 1
            harry "The clock can be edited. The paper is harder to fake."
            $ relation("harry", -1)
        "Ask Yan how they know the copy was resealed":
            $ trust += 1
            $ relation("yan", 1)
            yan "Because I sealed it."
            p "You made the copy?"
            yan "I made one copy. Not this one."
    hide yan portrait
    hide harry portrait
    narrator "A note is folded into the spine of the report."
    narrator "It reads: 'The call happened before the reason existed.'"
    show william portrait at left
    william "That's not a clue. That's a trap."
    show john portrait at right
    john "A trap can still tell you where the floor is weak."
    menu:
        "Tell the group the note's exact wording":
            $ trust += 1
            $ credibility += 1
            $ flags["shared_clue"] = True
            $ relation("john", 1)
            narrator "You read it aloud. Nobody writes it down."
        "Keep the wording private and test their reactions":
            $ influence += 2
            $ suspicion += 1
            narrator "You fold the note into your pocket."
            $ relation("william", -1)
        "Claim the note mentions a different time":
            $ credibility -= 2
            $ suspicion += 2
            narrator "You alter one word. Harry notices the pause before you speak."
            harry "You changed it."
            $ relation("harry", -2)
    $ clamp_stats()
    narrator "The archive terminal wakes without being touched."
    system "A DOCUMENT HAS BEEN ALTERED."
    system "THE AUTHOR IS NOT NECESSARILY THE FORGER."
    jump chapter_three

label chapter_three:
    $ chapter_seen = 3
    call screen chapter_card("CHAPTER 03", "The Message That Was Never Sent")
    scene bg dorm with fade
    narrator "At 03:06, every phone vibrates."
    $ add_message("UNKNOWN", "You are not receiving the same instructions.")
    $ add_message("UNKNOWN", "One of the five has already been promised a way out.")
    call screen phone_screen
    show yuki portrait at right
    yuki "I got a different message."
    p "What did it say?"
    yuki "It said not to trust the person who asks to see your screen."
    show harry portrait at left
    harry "Mine says one of us has already been selected as the winner."
    p "Who?"
    harry "It doesn't say."
    narrator "The messages are not merely anonymous. They are incompatible."
    $ add_evidence("Unequal messages: each participant appears to receive a different instruction.")
    menu:
        "Ask everyone to read their message aloud":
            $ trust += 2
            $ credibility += 1
            $ flags["sent_message"] = True
            $ relation("yuki", 1)
            narrator "For the first time, the six stories can be compared."
            john "Or six people can coordinate six lies."
        "Ask Yuki privately to show you her phone":
            $ relation("yuki", 2)
            $ trust += 1
            $ flags["protected_yuki"] = True
            yuki "I'll show you. But don't let them see the sender."
            $ add_evidence("Yuki's message warns against the person requesting phone access.")
        "Tell them your message says nothing":
            $ suspicion += 2
            $ influence += 1
            $ credibility -= 1
            narrator "You pocket the phone."
            william "That was the fastest answer in the room."
    $ clamp_stats()
    scene bg corridor with dissolve
    narrator "A second message arrives. This one has no sender."
    $ add_message("UNKNOWN", "THE FIRST PERSON TO TELL THE TRUTH WILL BE BELIEVED LAST.")
    unknown "You think the messages are a test of honesty."
    unknown "They are a test of what you do when honesty becomes expensive."
    p "Who are you?"
    unknown "A person who was not invited to play."
    narrator "The line disconnects."
    menu:
        "Reply: 'Then why are you here?'":
            $ add_message("YOU", "Then why are you here?")
            $ add_message("UNKNOWN", "Because one of them used my name.")
            $ suspicion += 1
            $ add_evidence("Unknown sender claims one participant used their name.")
        "Do not reply; preserve the number":
            $ credibility += 1
            $ add_evidence("Unknown sender number preserved without response.")
        "Forward the message to everyone":
            $ trust += 1
            $ influence -= 1
            $ add_message("SYSTEM", "Forward detected.")
            narrator "A tiny indicator appears: message copied."
    jump chapter_four

label chapter_four:
    $ chapter_seen = 4
    call screen chapter_card("CHAPTER 04", "The Six Seats")
    scene bg lounge with fade
    narrator "Six chairs. Five envelopes. One empty seat."
    system "INFORMATION ALLOCATION: THREE FILES, SIX PARTICIPANTS."
    system "EACH FILE MAY BE SHARED WITH TWO PEOPLE."
    narrator "The files are labelled: DEBT, IDENTITY, and EXIT."
    show john portrait at right
    john "We should pair up. One file each. No one gets everything."
    show yuki portrait at left
    yuki "That means someone is left out."
    john "That is what the rule says."
    menu:
        "Pair with Yuki and give her the EXIT file":
            $ relation("yuki", 2)
            $ trust += 2
            $ flags["protected_yuki"] = True
            $ add_evidence("EXIT file: door access requires two matching identity records.")
            yuki "The exit isn't a door. It's a record that says who is allowed to leave."
        "Pair with John and request the IDENTITY file":
            $ relation("john", 2)
            $ influence += 2
            $ add_evidence("IDENTITY file: one participant's registration predates the game.")
            john "Someone was registered before the other five. I don't know who."
        "Pair with Yan and request the DEBT file":
            $ relation("yan", 2)
            $ credibility += 1
            $ add_evidence("DEBT file: the liability was transferred twice before the game began.")
            yan "The debt is not William's. It was transferred into his name."
        "Refuse the pairings and demand all files be opened":
            $ suspicion += 2
            $ stress += 1
            $ influence -= 1
            harry "A principled demand. Conveniently impossible."
            $ add_evidence("Allocation rule: each file can be shared with only two people.")
    hide john portrait
    hide yuki portrait
    narrator "The excluded player is not announced."
    narrator "Instead, the system prints a sixth seat number: 00."
    system "SEAT 00 HAS BEEN OCCUPIED."
    p "There are only six of us."
    system "CORRECTION: THERE ARE SIX REGISTERED PLAYERS."
    narrator "The room goes silent. Nobody asks who is missing."
    $ stress += 2
    jump chapter_five

label chapter_five:
    $ chapter_seen = 5
    call screen chapter_card("CHAPTER 05", "An Incomplete Confession")
    scene bg archive with fade
    narrator "Harry asks to speak without the others."
    show harry portrait at center
    harry "I changed one thing in the report."
    p "Which thing?"
    harry "The call time. I moved it forward by eleven minutes."
    p "Why?"
    harry "Because the original time proved that someone had called before the debt was transferred."
    p "Who called?"
    harry "I don't know. The number was masked."
    narrator "He has confessed to altering evidence, but not to creating the debt."
    $ flags["confession_seen"] = True
    $ add_evidence("Harry's confession: he moved the report's call time by eleven minutes.")
    menu:
        "Ask Harry to identify who benefited":
            $ credibility += 2
            $ relation("harry", 1)
            harry "William. Or the person who wanted us to blame him."
        "Threaten to expose him unless he tells everything":
            $ influence += 2
            $ stress += 1
            $ relation("harry", -2)
            harry "Then expose me. The truth won't become cleaner because you shout."
        "Offer to keep the confession private for now":
            $ trust += 2
            $ relation("harry", 2)
            $ flags["secret_alliance"] = True
            harry "You may regret giving me time."
    hide harry portrait
    scene bg corridor with dissolve
    show william portrait at left
    william "He told you half of it."
    p "You knew?"
    william "I knew the timestamp was false. I didn't know who changed it."
    show yan portrait at right
    yan "Someone is using real mistakes to hide a larger one."
    narrator "A new file appears on the terminal. It contains a voice transcript."
    narrator "The final line is incomplete: 'The last alliance was never meant to...' "
    $ add_evidence("Partial transcript: 'The last alliance was never meant to...'")
    menu:
        "Complete the sentence with 'survive'":
            $ suspicion += 1
            $ influence += 1
            narrator "The terminal rejects your guess."
            system "PREDICTION STORED. NOT VERIFIED."
        "Complete it with 'exist'":
            $ credibility += 1
            narrator "The terminal pauses for three seconds."
            system "PREDICTION STORED. NOT VERIFIED."
        "Leave the sentence incomplete":
            $ trust += 1
            $ credibility += 1
            narrator "You refuse to let the machine choose your conclusion."
            system "INCOMPLETE ANSWERS ARE ALSO DATA."
    $ clamp_stats()
    jump chapter_six

label chapter_six:
    $ chapter_seen = 6
    call screen chapter_card("CHAPTER 06", "The Last Name")
    scene bg vote with fade
    narrator "The six nameplates light up."
    narrator "Five names are familiar. The sixth reads: ELIAS VENN."
    p "Who is Elias?"
    show yuki portrait at left
    yuki "That name was in my message."
    show john portrait at right
    john "No. It was in the original registration."
    narrator "John places a folded document on the table."
    john "I was hired to audit a case involving a person who vanished after reporting financial coercion."
    p "And you recognised the debt format because..."
    john "Because the debt belonged to Elias. William was made its public owner."
    show william portrait:
        xalign 0.25 yalign 1.0 zoom 0.7
    william "I signed the transfer. I thought it was a standard restructuring."
    show yan portrait:
        xalign 0.75 yalign 1.0 zoom 0.7
    yan "I copied the report because the first version named the wrong person."
    narrator "The pieces align, but not perfectly."
    narrator "Someone altered the timestamps. Someone divided the messages. Someone arranged the six seats."
    p "Who brought us here?"
    system "FINAL VOTE."
    system "CHOOSE WHAT THE GROUP SHOULD PRESERVE."
    menu:
        "Preserve the evidence, even if it exposes everyone":
            $ vote_record = "truth"
            $ flags["truth_route"] = True
            $ trust += 2
            $ credibility += 2
            $ influence += 1
        "Preserve the alliance and conceal the evidence":
            $ vote_record = "alliance"
            $ flags["secret_alliance"] = True
            $ trust += 2
            $ influence += 2
            $ suspicion += 1
        "Preserve yourself; trade one person's name for release":
            $ vote_record = "self"
            $ influence += 3
            $ credibility -= 2
            $ stress += 2
        "Refuse the vote and ask for Elias":
            $ vote_record = "elias"
            $ suspicion += 2
            $ credibility += 1
            $ flags["name_decoded"] = True
    $ clamp_stats()
    narrator "The screen asks for one final name."
    menu:
        "Name John":
            $ flags["confronted_john"] = True
            $ relation("john", -2)
            $ suspicion += 1
        "Name William":
            $ flags["voted_william"] = True
            $ relation("william", -2)
        "Name Harry":
            $ flags["voted_harry"] = True
            $ relation("harry", -2)
        "Name Yan":
            $ flags["voted_yan"] = True
            $ relation("yan", -2)
        "Name Yuki":
            $ flags["voted_yuki"] = True
            $ relation("yuki", -2)
        "Name Elias Venn":
            $ flags["name_decoded"] = True
            $ credibility += 2
            $ trust += 1
    jump ending_router

label ending_router:
    $ clamp_stats()
    if flags["truth_route"] and credibility >= 3 and "Carbon copy: two versions differ in punctuation, one name, and a call timestamp." in evidence:
        jump ending_truth
    elif flags["secret_alliance"] and trust >= 3 and relationships["yuki"] >= 1:
        jump ending_alliance
    elif vote_record == "self" or influence >= 6:
        jump ending_survivor
    elif flags["name_decoded"] and credibility >= 1:
        jump ending_name
    else:
        jump ending_loop

label ending_truth:
    scene black with fade
    centered "ENDING 01 // THE OPEN RECORD"
    narrator "You do not give the system a villain."
    narrator "You give it a chain of custody."
    narrator "The altered copy, the moved timestamp, the debt transfer, and the unequal messages are released together."
    narrator "No single confession can absorb the blame."
    show john portrait at right
    john "You understand what this means. None of us gets to choose the clean version."
    show yuki portrait at left
    yuki "But the next person won't have to start in the dark."
    system "ARCHIVE MIRRORING: COMPLETE."
    narrator "The door opens. Outside, dawn has already begun."
    narrator "You leave without knowing who designed the game."
    narrator "For the first time, not knowing is not the same as being deceived."
    return

label ending_alliance:
    scene black with fade
    centered "ENDING 02 // THE LAST ALLIANCE"
    narrator "You choose the people over the proof."
    narrator "Yuki keeps the EXIT file. Yan keeps the original copy. William keeps the debt transfer hidden."
    narrator "The group walks out together, carrying a secret that can still destroy them."
    yuki "Do you trust us?"
    p "No."
    yuki "Good. Then we might survive."
    narrator "A message arrives after the doors open."
    $ add_message("UNKNOWN", "ALLIANCE CONFIRMED. PHASE TWO PENDING.")
    narrator "The game has not ended. It has changed owners."
    return

label ending_survivor:
    scene black with fade
    centered "ENDING 03 // THE ONLY SURVIVOR"
    narrator "You traded a name for a door."
    narrator "The others are not punished in front of you. That would have been kinder."
    system "INDIVIDUAL RELEASE APPROVED."
    narrator "Your phone lights up outside."
    $ add_message("UNKNOWN", "YOU WERE NEVER THE PRIZE.")
    narrator "The payment clears. The guilt does not."
    narrator "You survived the room. You did not escape the game."
    return

label ending_name:
    scene black with fade
    centered "ENDING 04 // ELIAS VENN"
    narrator "You speak the name that the system tried to turn into a missing seat."
    narrator "The room unlocks, but the archive opens first."
    narrator "Elias was not the sixth player. Elias was the reason the five others were selected."
    narrator "A photograph appears: a younger version of the person who designed the test."
    narrator "The caption reads: 'Witness, not architect.'"
    narrator "You have found the name. Not the hand behind it."
    return

label ending_loop:
    scene black with fade
    centered "ENDING 05 // THE SIXTH SEAT"
    narrator "The final vote is counted."
    narrator "The door remains closed."
    system "CONSENSUS NOT REACHED."
    narrator "A new envelope slides from the table."
    narrator "It contains six blank voting cards."
    narrator "The clock begins to move."
    narrator "Somewhere behind the wall, someone says your name."
    return
