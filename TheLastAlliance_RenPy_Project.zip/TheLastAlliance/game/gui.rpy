# Minimal GUI initialization for Ren'Py 8.x.
init python:
    gui.init(1920, 1080)
    gui.text_font = "gui/DejaVuSans.ttf"
    gui.name_text_font = "gui/DejaVuSans.ttf"
    gui.interface_text_font = "gui/DejaVuSans.ttf"
    gui.text_size = 34
    gui.name_text_size = 32
    gui.interface_text_size = 28
    gui.label_text_size = 42
    gui.button_text_size = 30
    gui.choice_button_width = 1100
    gui.choice_button_height = 88
    gui.dialogue_text_xpos = 80
    gui.dialogue_text_ypos = 45
    gui.dialogue_text_width = 1760
    gui.dialogue_text_size = 34
    gui.name_xpos = 105
    gui.name_ypos = 8
    gui.textbox_height = 270
    gui.textbox_yalign = 1.0
    gui.accent_color = "#b51f2b"
    gui.idle_color = "#888888"
    gui.hover_color = "#ffffff"
    gui.selected_color = "#b51f2b"
    gui.insensitive_color = "#555555"
    gui.text_color = "#eeeeee"
    gui.interface_text_color = "#eeeeee"

default quick_menu = True
