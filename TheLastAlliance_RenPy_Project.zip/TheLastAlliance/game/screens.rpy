# Custom screens: compact mobile-friendly HUD, evidence archive and secure phone.
screen stat_hud():
    zorder 80
    if not main_menu:
        frame:
            xalign 0.985
            yalign 0.025
            xsize 420
            background Solid("#08090ddd")
            padding (22, 18)
            vbox:
                spacing 8
                text "MENTAL STATE // LIVE" size 22 color "#b51f2b"
                text "TRUST       [trust] / 10" size 22
                bar value AnimatedValue(value=trust+10, range=20, delay=0.25) xsize 360 ysize 9
                text "SUSPICION   [suspicion] / 10" size 22
                bar value AnimatedValue(value=suspicion+10, range=20, delay=0.25) xsize 360 ysize 9
                text "STRESS      [stress] / 10" size 22
                bar value AnimatedValue(value=stress, range=10, delay=0.25) xsize 360 ysize 9
                text "CREDIBILITY [credibility] / 10" size 22
                bar value AnimatedValue(value=credibility+10, range=20, delay=0.25) xsize 360 ysize 9
                text "INFLUENCE   [influence] / 10" size 22
                bar value AnimatedValue(value=influence+10, range=20, delay=0.25) xsize 360 ysize 9
screen evidence_screen():
    modal True
    add Solid("#000000e8")
    frame:
        xalign 0.5 yalign 0.5 xsize 1450 ysize 850
        background Solid("#111216")
        padding (50,40)
        vbox:
            spacing 22
            hbox:
                text "EVIDENCE ARCHIVE" size 46 color "#c52b36"
                null width 500
                textbutton "CLOSE [X]" action Hide("evidence_screen")
            text "Collected fragments. Their meaning is not guaranteed." size 25 color "#999999"
            if evidence:
                for item in evidence:
                    frame:
                        xfill True
                        background Solid("#202126")
                        padding (20,16)
                        text "▸ [item]" size 29
            else:
                text "No evidence collected." color "#777777" size 30
            text "A clue can be authentic and still be used to tell a lie." size 24 italic True color "#aaaaaa"

screen phone_screen():
    modal True
    add Solid("#000000e8")
    frame:
        xalign 0.5 yalign 0.5 xsize 1050 ysize 850
        background Solid("#090a0d")
        padding (36,30)
        vbox:
            spacing 18
            hbox:
                text "SECURE LINE" size 42 color "#c52b36"
                null width 400
                textbutton "CLOSE [X]" action Hide("phone_screen")
            viewport:
                draggable True
                mousewheel True
                ysize 610
                vbox:
                    spacing 12
                    if messages:
                        for msg in messages:
                            frame:
                                xfill True
                                background Solid("#20232a")
                                padding (18,14)
                                vbox:
                                    text "[msg['sender']]" size 20 color "#c52b36"
                                    text "[msg['body']]" size 27
                    else:
                        text "No messages. The silence is deliberate." size 27 color "#888888"
            text "Messages may be incomplete, delayed, or selectively delivered." size 21 color "#888888"

screen chapter_card(chapter, subtitle):
    modal True
    add Solid("#050506")
    vbox:
        xalign 0.5 yalign 0.5 spacing 24
        text "THE LAST ALLIANCE" size 32 color "#777777" xalign 0.5
        text "[chapter]" size 64 color "#c52b36" xalign 0.5
        text "[subtitle]" size 31 color "#eeeeee" xalign 0.5
        textbutton "ENTER" action Return() xalign 0.5

screen main_menu():
    tag menu
    add "images/main_menu.png"
    frame:
        xalign 0.12 yalign 0.52
        xsize 500
        background Solid("#050505aa")
        padding (30,28)
        vbox:
            spacing 12
            text "THE LAST" size 42 color "#eeeeee"
            text "ALLIANCE" size 62 color "#c52b36"
            text "Trust is a lie. Survival is the only truth." size 20 color "#cccccc"
            null height 20
            textbutton "NEW GAME" action Start() text_size 34
            textbutton "CONTINUE" action Continue() text_size 34
            textbutton "LOAD" action ShowMenu("load") text_size 34
            textbutton "SETTINGS" action ShowMenu("preferences") text_size 34
            textbutton "QUIT" action Quit(confirm=True) text_size 34
    text "REN'PY VISUAL NOVEL  //  BUILD 1.0" xalign 0.02 yalign 0.98 size 18 color "#999999"

screen navigation():
    vbox:
        style_prefix "navigation"
        xpos 30
        yalign 0.5
        spacing 10
        if main_menu:
            textbutton _("Start") action Start()
        else:
            textbutton _("History") action ShowMenu("history")
            textbutton _("Save") action ShowMenu("save")
        textbutton _("Load") action ShowMenu("load")
        textbutton _("Preferences") action ShowMenu("preferences")
        textbutton _("Main Menu") action MainMenu()
        textbutton _("About") action ShowMenu("about")
        textbutton _("Quit") action Quit(confirm=True)

screen quick_menu():
    zorder 100
    if quick_menu and not main_menu:
        hbox:
            style_prefix "quick"
            xalign 0.99
            yalign 0.015
            spacing 18
            textbutton "EVIDENCE" action Show("evidence_screen")
            textbutton "PHONE" action Show("phone_screen")
            textbutton "SAVE" action ShowMenu("save")
            textbutton "MENU" action ShowMenu("game_menu")

init python:
    config.overlay_screens.append("stat_hud")
    config.overlay_screens.append("quick_menu")


# Explicit save/load/preferences screens so the project does not depend on a template.
screen save():
    tag menu
    use file_slots("SAVE GAME")

screen load():
    tag menu
    use file_slots("LOAD GAME")

screen file_slots(title):
    modal True
    add Solid("#08090df0")
    frame:
        xalign 0.5 yalign 0.5
        xsize 1500 ysize 900
        background Solid("#15161b")
        padding (38,30)
        vbox:
            spacing 22
            hbox:
                text "[title]" size 46 color "#c52b36"
                null width 800
                textbutton "RETURN" action Return()
            hbox:
                spacing 12
                for page in range(1, 9):
                    textbutton "[page]" action FilePage(page)
                textbutton "AUTO" action FilePage("auto")
                textbutton "QUICK" action FilePage("quick")
            grid 3 2:
                spacing 18
                for i in range(6):
                    button:
                        xsize 450 ysize 290
                        background Solid("#25272d")
                        hover_background Solid("#343740")
                        action (FileSave(i) if title == "SAVE GAME" else FileLoad(i))
                        has vbox
                        spacing 8
                        add FileScreenshot(i) xsize 420 ysize 210
                        text FileSlotName(i) size 22
                        text FileTime(i, format=_("{#file_time}%Y-%m-%d %H:%M"), empty=_("Empty Slot")) size 18 color "#aaaaaa"

screen preferences():
    tag menu
    modal True
    add Solid("#08090df0")
    frame:
        xalign 0.5 yalign 0.5
        xsize 1200 ysize 760
        background Solid("#15161b")
        padding (50,40)
        vbox:
            spacing 28
            hbox:
                text "SETTINGS" size 48 color "#c52b36"
                null width 650
                textbutton "RETURN" action Return()
            text "DISPLAY" size 28 color "#aaaaaa"
            hbox:
                textbutton "WINDOW" action Preference("display", "window")
                textbutton "FULLSCREEN" action Preference("display", "fullscreen")
            text "AUDIO" size 28 color "#aaaaaa"
            hbox:
                text "MUSIC" size 24
                bar value Preference("music volume") xsize 400
            hbox:
                text "SOUND" size 24
                bar value Preference("sound volume") xsize 400
            text "TEXT" size 28 color "#aaaaaa"
            hbox:
                text "TEXT SPEED" size 24
                bar value Preference("text speed") xsize 400
            hbox:
                text "AUTO-FORWARD" size 24
                bar value Preference("auto-forward time") xsize 400
