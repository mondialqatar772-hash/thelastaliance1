# Persistent narrative variables and relationship model.
default trust = 0
default suspicion = 0
default stress = 0
default credibility = 0
default influence = 0
default relationships = {"john": 0, "william": 0, "harry": 0, "yan": 0, "yuki": 0}
default flags = {
    "found_debt": False, "kept_card": False, "shared_clue": False,
    "forged_copy": False, "sent_message": False, "protected_yuki": False,
    "confronted_john": False, "confession_seen": False, "name_decoded": False,
    "secret_alliance": False, "voted_william": False, "voted_harry": False,
    "voted_yan": False, "voted_yuki": False, "truth_route": False
}
default evidence = []
default messages = []
default chapter_seen = 0
default vote_record = "abstain"
default player_name = "You"
default alliance_score = 0

init python:
    def add_evidence(item):
        if item not in evidence:
            evidence.append(item)

    def add_message(sender, body):
        messages.append({"sender": sender, "body": body})

    def relation(person, amount):
        relationships[person] = max(-5, min(5, relationships.get(person, 0) + amount))

    def clamp_stats():
        global trust, suspicion, stress, credibility, influence
        trust = max(-10, min(10, trust))
        suspicion = max(-10, min(10, suspicion))
        stress = max(0, min(10, stress))
        credibility = max(-10, min(10, credibility))
        influence = max(-10, min(10, influence))

    def stat_label(value):
        if value >= 6: return "HIGH"
        if value >= 2: return "RISING"
        if value <= -5: return "CRITICAL"
        if value <= -1: return "LOW"
        return "UNSETTLED"

    def ending_score():
        return trust + credibility + influence + sum(relationships.values()) - suspicion - stress
