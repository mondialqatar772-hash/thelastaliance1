# Character definitions. Portraits are original generated monochrome assets.
define narrator = Character(None)
define p = Character("[player_name]", color="#eeeeee")
define john = Character("JOHN", color="#d7d7d7")
define william = Character("WILLIAM", color="#bdbdbd")
define harry = Character("HARRY", color="#e5e5e5")
define yan = Character("YAN", color="#aaaaaa")
define yuki = Character("YUKI", color="#f0f0f0")
define system = Character("SYSTEM", color="#c52b36")
define unknown = Character("UNKNOWN", color="#c52b36")
image player portrait = "images/player.png"
image john portrait = "images/john.png"
image william portrait = "images/william.png"
image harry portrait = "images/harry.png"
image yan portrait = "images/yan.png"
image yuki portrait = "images/yuki.png"
image bg lounge = "images/bg_lounge.png"
image bg corridor = "images/bg_corridor.png"
image bg archive = "images/bg_archive.png"
image bg dorm = "images/bg_dorm.png"
image bg vote = "images/bg_vote.png"
